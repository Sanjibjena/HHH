
class Foo extends Baz {
    test: string;
}

class Bar {

}