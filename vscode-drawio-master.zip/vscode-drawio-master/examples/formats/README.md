Draw.io diagrams can be embedded in markdown files!

SVG Diagram:

![](./Example.dio.svg)

PNG Diagram:

![](./Example.drawio.png)
